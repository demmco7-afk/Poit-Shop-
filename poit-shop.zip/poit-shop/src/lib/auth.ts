import { SignJWT, jwtVerify } from "jose"; import { cookies } from "next/headers"; import { NextResponse } from "next/server"
const key = () => new TextEncoder().encode(process.env.AUTH_SECRET || "")
export type Session = { id: string; role: string }
export async function setSession(id: string, role: string) {
  const t = await new SignJWT({ id, role }).setProtectedHeader({ alg: "HS256" }).setExpirationTime("7d").sign(key())
  cookies().set("poit_session", t, { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", path: "/", maxAge: 604800 })
}
export async function getSession(): Promise<Session | null> {
  const t = cookies().get("poit_session")?.value; if (!t) return null
  try { return (await jwtVerify(t, key())).payload as unknown as Session } catch { return null }
}
// Pemeriksaan hak akses SELALU di backend
export async function requireRole(roles: string[]) {
  const s = await getSession()
  if (!s) return { error: NextResponse.json({ error: "Belum login" }, { status: 401 }) }
  if (!roles.includes(s.role)) return { error: NextResponse.json({ error: "Tidak punya akses" }, { status: 403 }) }
  return { session: s }
}
