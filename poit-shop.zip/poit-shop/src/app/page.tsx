import { db } from "@/lib/db"
export const dynamic = "force-dynamic"
export default async function Home() {
  const [cats, products] = await Promise.all([db.category.findMany(), db.product.findMany({ where: { active: true }, orderBy: { createdAt: "desc" }, take: 12 })])
  return (<main className="wrap">
    <section className="hero"><h1>Belanja game, produk digital, dan jasa di satu tempat.</h1><p>Akun game, joki, top up, voucher, dan jasa digital dengan pembayaran yang diverifikasi.</p></section>
    <h2>Kategori</h2><div className="cats">{cats.map(c => <div className="cat" key={c.id}>{c.name}</div>)}</div>
    <h2>Produk terbaru</h2>
    {products.length === 0 ? <div className="empty">Belum ada produk. Login sebagai Owner lalu tambahkan produk pertama.</div>
      : <div className="grid">{products.map(p => <div className="card" key={p.id}><div>{p.name}</div><div className="mute">Stok {p.stock}</div><div className="price">Rp {p.price.toLocaleString("id-ID")}</div></div>)}</div>}
  </main>)
}
