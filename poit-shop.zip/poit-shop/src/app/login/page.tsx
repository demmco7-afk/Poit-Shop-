"use client"; import { useState } from "react"
export default function Login() {
  const [mode, setMode] = useState<"login" | "register">("login"); const [err, setErr] = useState("")
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setErr("")
    const f = e.currentTarget.elements; const v = (n: string) => (f.namedItem(n) as HTMLInputElement | null)?.value
    const r = await fetch(`/api/auth/${mode}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name: v("name"), email: v("email"), password: v("password") }) })
    const d = await r.json(); if (!r.ok) return setErr(d.error); window.location.href = "/"
  }
  return (<form className="box" onSubmit={submit}>
    <h2 style={{ margin: 0 }}>{mode === "login" ? "Masuk" : "Buat akun"}</h2>
    {mode === "register" && <input name="name" placeholder="Nama" required />}
    <input name="email" type="email" placeholder="Email" required />
    <input name="password" type="password" placeholder="Password (min. 8 karakter)" required />
    {err && <div className="err">{err}</div>}
    <button className="btn">{mode === "login" ? "Masuk" : "Daftar"}</button>
    <button type="button" className="btn alt" onClick={() => setMode(mode === "login" ? "register" : "login")}>{mode === "login" ? "Belum punya akun? Daftar" : "Sudah punya akun? Masuk"}</button>
  </form>)
}
