import "./globals.css"; import Link from "next/link"; import { getSession } from "@/lib/auth"
export const metadata = { title: "POIT SHOP", description: "One Platform. Multiple Businesses." }
export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const s = await getSession()
  return (<html lang="id"><body>
    <header><div className="wrap"><Link href="/" className="logo">POIT<b>SHOP</b></Link><span className="sp" />
      {s ? <span className="mute">Masuk sebagai {s.role}</span> : <Link href="/login" className="btn alt">Masuk</Link>}</div></header>
    {children}
    <footer><div className="wrap">POIT SHOP. One Platform. Multiple Businesses.</div></footer>
  </body></html>)
}
