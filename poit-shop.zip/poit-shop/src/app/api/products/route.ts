import { NextResponse } from "next/server"; import { db } from "@/lib/db"
export async function GET(req: Request) {
  const slug = new URL(req.url).searchParams.get("category")
  const products = await db.product.findMany({ where: { active: true, ...(slug ? { category: { slug } } : {}) }, include: { category: true }, orderBy: { createdAt: "desc" }, take: 50 })
  return NextResponse.json(products)
}
