import { NextResponse } from "next/server"; import { z } from "zod"
import { db } from "@/lib/db"; import { requireRole } from "@/lib/auth"
const TYPES = ["MANUAL","QRIS_GATEWAY","EWALLET_GATEWAY","VIRTUAL_ACCOUNT","CUSTOM_API"] as const
const schema = z.object({ name: z.string().min(2), type: z.enum(TYPES), accountNumber: z.string().optional(), accountName: z.string().optional(),
  fee: z.number().int().min(0).default(0), minAmount: z.number().int().min(0).default(0), maxAmount: z.number().int().optional(), sortOrder: z.number().int().default(0), active: z.boolean().default(true) })
export async function GET() {
  const a = await requireRole(["OWNER","ADMIN"]); if (a.error) return a.error
  return NextResponse.json(await db.paymentMethod.findMany({ orderBy: { sortOrder: "asc" } }))
}
export async function POST(req: Request) {
  const a = await requireRole(["OWNER","ADMIN"]); if (a.error) return a.error
  const p = schema.safeParse(await req.json().catch(() => ({})))
  if (!p.success) return NextResponse.json({ error: "Data tidak valid" }, { status: 400 })
  const m = await db.paymentMethod.create({ data: p.data })
  await db.auditLog.create({ data: { userId: a.session!.id, action: "PAYMENT_METHOD_CREATE", detail: m.id } })
  return NextResponse.json(m, { status: 201 })
}
