import { NextResponse } from "next/server"; import { z } from "zod"; import bcrypt from "bcryptjs"
import { db } from "@/lib/db"; import { setSession } from "@/lib/auth"
const schema = z.object({ name: z.string().min(2).max(60), email: z.string().email(), password: z.string().min(8).max(100) })
export async function POST(req: Request) {
  const p = schema.safeParse(await req.json().catch(() => ({})))
  if (!p.success) return NextResponse.json({ error: "Data tidak valid. Password minimal 8 karakter." }, { status: 400 })
  const email = p.data.email.toLowerCase()
  if (await db.user.findUnique({ where: { email } })) return NextResponse.json({ error: "Email sudah terdaftar" }, { status: 409 })
  const u = await db.user.create({ data: { email, name: p.data.name, passwordHash: await bcrypt.hash(p.data.password, 12) } })
  await setSession(u.id, u.role)
  return NextResponse.json({ ok: true })
}
