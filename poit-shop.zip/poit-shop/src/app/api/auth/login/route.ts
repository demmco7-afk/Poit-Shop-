import { NextResponse } from "next/server"; import bcrypt from "bcryptjs"
import { db } from "@/lib/db"; import { setSession } from "@/lib/auth"
const tries = new Map<string, { n: number; t: number }>() // pembatas sederhana, per proses
export async function POST(req: Request) {
  const { email, password } = await req.json().catch(() => ({}))
  const k = String(email || "").toLowerCase(), now = Date.now(), r = tries.get(k)
  if (r && now - r.t < 600000 && r.n >= 5) return NextResponse.json({ error: "Terlalu banyak percobaan. Coba lagi 10 menit." }, { status: 429 })
  const u = k ? await db.user.findUnique({ where: { email: k } }) : null
  if (!u || !(await bcrypt.compare(String(password || ""), u.passwordHash))) {
    tries.set(k, { n: (r && now - r.t < 600000 ? r.n : 0) + 1, t: r?.t ?? now })
    return NextResponse.json({ error: "Email atau password salah" }, { status: 401 })
  }
  tries.delete(k); await setSession(u.id, u.role)
  return NextResponse.json({ ok: true, role: u.role })
}
